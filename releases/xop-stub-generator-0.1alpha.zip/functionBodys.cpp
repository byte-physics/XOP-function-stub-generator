


// string getBugReportTemplate()
static int getBugReportTemplate(getBugReportTemplateParams *p){

	return 0;
}





// variable getFileName(string *filename)
static int getFileName(getFileNameParams *p){

	return 0;
}





// variable openFile(string absoluteFilePath, string fileName)
static int openFile(openFileParams *p){

	return 0;
}






static long RegisterFunction()
{
	/*	NOTE:
		Some XOPs should return a result of NIL in response to the FUNCADDRS message.
		See XOP manual "Restrictions on Direct XFUNCs" section.
	*/

	int funcIndex = GetXOPItem(0);		/* which function invoked ? */
	long returnValue = NIL;

	switch (funcIndex) {
		case 0:						
			returnValue = (long) getBugReportTemplate;
			break;
		case 1:						
			returnValue = (long) getFileName;
			break;
		case 2:						
			returnValue = (long) openFile;
			break;

	}
	return returnValue;
}
