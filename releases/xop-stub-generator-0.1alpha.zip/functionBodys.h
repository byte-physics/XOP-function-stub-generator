

#pragma pack(2)	// All structures passed to Igor are two-byte aligned.
struct getBugReportTemplateParams{
	Handle  result;
};
typedef struct getBugReportTemplateParams getBugReportTemplateParams;
#pragma pack()

static int getBugReportTemplate(getBugReportTemplateParams *p);
#pragma pack(2)	// All structures passed to Igor are two-byte aligned.
struct getFileNameParams{
	Handle *filename;
	double  result;
};
typedef struct getFileNameParams getFileNameParams;
#pragma pack()

static int getFileName(getFileNameParams *p);
#pragma pack(2)	// All structures passed to Igor are two-byte aligned.
struct openFileParams{
	Handle  fileName;
	Handle  absoluteFilePath;
	double  result;
};
typedef struct openFileParams openFileParams;
#pragma pack()

static int openFile(openFileParams *p);


