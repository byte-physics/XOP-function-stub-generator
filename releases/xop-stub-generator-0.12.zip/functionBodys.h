

#pragma pack(2)	// All structures passed to Igor are two-byte aligned.
struct getBugReportTemplateParams{
	Handle  result;
};
typedef struct getBugReportTemplateParams getBugReportTemplateParams;
#pragma pack()

#pragma pack(2)	// All structures passed to Igor are two-byte aligned.
struct getFileNameParams{
	Handle *filename;
	UserFunctionThreadInfoPtr tp; // needed for thread safe functions
	double  result;
};
typedef struct getFileNameParams getFileNameParams;
#pragma pack()

#pragma pack(2)	// All structures passed to Igor are two-byte aligned.
struct openFileParams{
	Handle  fileName;
	Handle  absoluteFilePath;
	double  result;
};
typedef struct openFileParams openFileParams;
#pragma pack()



