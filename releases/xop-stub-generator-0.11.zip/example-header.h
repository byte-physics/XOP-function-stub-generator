/*
 * Author:  Thomas Braun
 * License: GPLv3 or later
 * Version: 0.1
 * Date: 6/30/201
 * 
 * Purpose: Example file for create-xop-stubs.pl
*/

variable openFile(string absoluteFilePath, string fileName);
string getBugReportTemplate();
variable getFileName(string *filename);

