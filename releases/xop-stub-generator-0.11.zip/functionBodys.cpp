


// string getBugReportTemplate()
extern "C" int getBugReportTemplate(getBugReportTemplateParams *p){

	return 0;
}





// variable getFileName(string *filename)
extern "C" int getFileName(getFileNameParams *p){

	return 0;
}





// variable openFile(string absoluteFilePath, string fileName)
extern "C" int openFile(openFileParams *p){

	return 0;
}






static long RegisterFunction()
{
	/*	NOTE:
		Some XOPs should return a result of NIL in response to the FUNCADDRS message.
		See XOP manual "Restrictions on Direct XFUNCs" section.
	*/

	int funcIndex = GetXOPItem(0);		/* which function invoked ? */
	XOPIORecResult returnValue = NIL;

	switch (funcIndex) {
		case 0:						
			returnValue = (XOPIORecResult) getBugReportTemplate;
			break;
		case 1:						
			returnValue = (XOPIORecResult) getFileName;
			break;
		case 2:						
			returnValue = (XOPIORecResult) openFile;
			break;

	}
	return returnValue;
}
